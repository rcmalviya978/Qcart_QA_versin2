curl -O https://gitlab.crio.do/crio_bytes/selenium/me_selenium_web_actions/-/raw/master/SeleniumWebActions/selenium-run.sh
chmod +x selenium-run.sh